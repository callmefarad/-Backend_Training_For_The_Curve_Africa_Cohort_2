// A module is a file containing some piece/chunks of code that can be reuseable.
// We can gain access to a module by using the require()

// structure of a module
// const someVariable = require('someModule')
console.log("modules")

