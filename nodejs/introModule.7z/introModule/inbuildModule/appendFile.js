const fileSystem = require( 'fs' );
fileSystem.appendFileSync( './sample1.txt', "\n13. ubani monday" )