const fileSystem = require('fs')

// writing to a file
fileSystem.writeFileSync( './sample1.txt', "12. ubani friday" );